<?php

	require_once 'conex.php';

	date_default_timezone_set('America/Lima');
	$fecha = date("Y-m-d H:i:s");

	//Esta variable será para imprimir el formato json desde el api
	$json = array('respuesta' => 'ERROR');

	$logueo = new ArrayObject( array() , 2 );
	$logueo->usuario = "";
	$logueo->votacion = "";


	//Recibimos por el método $_GET
	if( isset($_GET['usuario']) && $_GET['usuario'] != ''  ){
		$logueo->usuario = htmlentities(strip_tags($_GET['usuario']));
	}

	//Recibimos por el método $_GET
	if( isset($_GET['votacion']) && $_GET['votacion'] != ''  ){
		$logueo->votacion = htmlentities(strip_tags($_GET['votacion']));
	}

	if ( $logueo->usuario != '' && $logueo->votacion != '' ) {

		$sql = "SELECT * FROM votacion_usuario 
				WHERE idusuario = '$logueo->usuario' ";

		$query = mysql_query($sql);
		$total = mysql_fetch_assoc($query);
		
		if( $total > 1 ){
			//Ya voto!!
			$json['mensaje'] = "Ya votastes peee!!!";

		}else{
			//No existe el registro
			$json = array('respuesta' => 'OK');
			$json['mensaje'] = "Voto ingresado correctamente";
			
			$sqlInsert = "INSERT INTO votacion_usuario( idusuario, idvotacion, registro ) 
							VALUES( '$logueo->usuario', '$logueo->votacion' , '$fecha' )";
			$queryInsert = mysql_query($sqlInsert);

			//Actualizamos la opcion de votacion del usuario para que no vuelva a votar
			$sqlInsert = "UPDATE usuario SET votacion = '1' WHERE id = '$logueo->usuario' ";
			$queryInsert = mysql_query($sqlInsert);
			
		}
		
	}else{
		$json['mensaje'] = 'Revise los datos ingresados';
	}

	echo json_encode($json);

?>