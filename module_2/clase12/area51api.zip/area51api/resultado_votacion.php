<?php

	require_once 'conex.php';

	$json = array('respuesta' => 'OK',
				  'mensaje' => 'Lista de resultado de votacion');

	$sql = "SELECT id, nombre , 
			( SELECT COUNT(*) FROM votacion_usuario WHERE idvotacion = V.id ) AS VOTOS
			FROM votacion V";

	$query = mysql_query($sql);

	while ( $datasql = mysql_fetch_assoc($query) ) {
		$json['datos'][] = $datasql;
	}

	echo json_encode($json);

?>