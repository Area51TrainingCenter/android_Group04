/** Automatically generated file. DO NOT MODIFY */
package com.area51.clase12;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}