<?php

	require_once 'conex.php';

	$json = array('respuesta' => 'OK',
				  'mensaje' => 'Lista de votacion');

	$sql = "SELECT * FROM votacion";
	$query = mysql_query($sql);

	while ( $datasql = mysql_fetch_assoc($query) ) {
		$json['datos'][] = $datasql;
	}

	echo json_encode($json);

?>