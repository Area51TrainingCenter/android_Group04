package com.area51.utils;

public class ConstantsUtils {
	
	public static final String URL_ROOT_TWITTER_API = "https://api.twitter.com";
	public static final String URL_SEARCH = URL_ROOT_TWITTER_API + "/1.1/search/tweets.json?q=";
	public static final String URL_AUTHENTICATION = URL_ROOT_TWITTER_API + "/oauth2/token";

	public static final String CONSUMER_KEY = "dWmeKRNKsWdfzVV1nzC4bQ";
	public static final String CONSUMER_SECRET = "E5MFYncRb0ufR9qWfdReyTxIU2TIux3640V0qeX2Qc";
	
	public static final String TWITTER_TERM = "desvelopers";
	public static final String TWITTER_COUNT = "10";
	

}
